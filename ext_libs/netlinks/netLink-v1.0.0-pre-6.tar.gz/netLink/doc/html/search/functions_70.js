var searchData=
[
  ['portfrom',['portFrom',['../class_n_l_1_1_socket.html#af44526feba01c807632df3a20c0446e5',1,'NL::Socket']]],
  ['portto',['portTo',['../class_n_l_1_1_socket.html#af86ff00d3ba6dd25bededad562a4473a',1,'NL::Socket']]],
  ['protocol',['protocol',['../class_n_l_1_1_socket.html#a5aaff0a58341ca5c49727572162b3139',1,'NL::Socket']]]
];
