var searchData=
[
  ['listen',['listen',['../class_n_l_1_1_socket_group.html#a7991c19d8fd2e08e5deab0605917b47e',1,'NL::SocketGroup']]],
  ['listenqueue',['listenQueue',['../class_n_l_1_1_socket.html#a9dd1a04f4c313a01bac3adfe6ba63688',1,'NL::Socket']]]
];
